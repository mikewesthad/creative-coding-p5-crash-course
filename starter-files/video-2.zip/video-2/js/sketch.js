/*
	Video 2 - Vanilla JS!

	⊂(◉‿◉)つ
*/