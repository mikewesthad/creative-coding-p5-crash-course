/*
	Links

	- RGB picker: https://codepen.io/mikewesthad/pen/prwReJ
	- p5 Reference: http://p5js.org/reference/. See the structure, shape and
	  color sections.
	
	Challenge:

	- Try combining two or more different colored shapes to create a pattern,
	  e.g. how would you create a bullseye? Bonus points if you use something
	  new from the p5 reference page.
*/